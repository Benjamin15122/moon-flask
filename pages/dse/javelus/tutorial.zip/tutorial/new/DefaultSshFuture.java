import java.lang.reflect.Array;
import java.util.Arrays;

 
public class DefaultSshFuture {

    private Object listeners;

    public void addListener(SshFutureListener listener) {
        System.out.println("Version 2: Add listener " + listener);
        if (listeners == null) {
            listeners = listener;
        } else if (listeners instanceof SshFutureListener) {
            listeners = new Object[] { listeners, listener };
        } else {
            Object[] ol = (Object[]) listeners;
            int l = ol.length;
            Object[] nl = new Object[l + 1];
            System.arraycopy(ol, 0, nl, 0, l);
            nl[l] = listener;
            listeners = nl;
        }
    }

    public void removeListener(SshFutureListener listener) {
        System.out.println("Version 2: Remove listener " + listener);
        if (listeners != null) {
            if (listeners == listener) {
                listeners = null;
            } else {
                int l = Array.getLength(listeners);
                for (int i = 0; i < l; i++) {
                    if (Array.get(listeners, i) == listener) {
                        Array.set(listeners, i, null);
                        break;
                    }
                }
            }
        }
    }

    public String toString() {
        if (listeners instanceof Object[]) {
            return "Version 2: listeners=" + Arrays.asList((Object[])listeners);
        }
        return "Version 2: listeners=" + listeners;
    }
}
