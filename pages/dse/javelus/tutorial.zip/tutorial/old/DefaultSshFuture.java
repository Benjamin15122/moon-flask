import java.util.ArrayList;
import java.util.List;

public class DefaultSshFuture {

    private SshFutureListener firstListener;
    private List<SshFutureListener> otherListeners;

    public void addListener(SshFutureListener listener) {
        System.out.println("Version 1: Add listener " + listener);
        if (firstListener == null) {
            firstListener = listener;
        } else {
            if (otherListeners == null) {
                otherListeners = new ArrayList<SshFutureListener>(1);
            }
            otherListeners.add(listener);
        }
    }

    public void removeListener(SshFutureListener listener) {
        System.out.println("Version 1: Remove listener " + listener);
        if (listener == firstListener) {
            if (otherListeners != null && !otherListeners.isEmpty()) {
                firstListener = otherListeners.remove(0);
            } else {
                firstListener = null;
            }
        } else if (otherListeners != null) {
            otherListeners.remove(listener);
        }
    }

    public String toString() {
        return "Version 1: first=" + firstListener +  ", others=" + otherListeners;
    }
}
