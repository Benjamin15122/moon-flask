public class Main {

    public static void main(String[] args) {
        DefaultSshFuture object = new DefaultSshFuture();
        SshFutureListener l1 = new SshFutureListener();
        SshFutureListener l2 = new SshFutureListener();
        SshFutureListener l3 = new SshFutureListener();
        object.addListener(l1);
        object.addListener(l2);
        object.addListener(l3);
        System.out.println(object);

        org.javelus.DeveloperInterface.invokeDSU();

        System.out.println(object);
        object.removeListener(l1);
        object.removeListener(l2);
        object.removeListener(l3);
        object.addListener(l1);
        object.addListener(l2);
        object.addListener(l3);
        System.out.println(object);
    }
}
