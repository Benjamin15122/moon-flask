import java.util.ArrayList;
import java.util.List;

import org.javelus.OldField;

public class DefaultSshFuture {

    private Object listeners;

    public void updateObject(		@OldField(clazz="DefaultSshFuture", name="firstListener",signature="LSshFutureListener;")
            SshFutureListener firstListener,
            @OldField(clazz="DefaultSshFuture", name="otherListeners",signature="Ljava/util/List;")
            java.util.List otherListeners	){

        if (firstListener != null) {
            listeners = firstListener;
            if (otherListeners != null) {
                int size = otherListeners.size();
                Object[] array = new Object[size + 1]; // include the firstListener
                array[0] = firstListener;
                for (int i = 0; i < size; i++) {
                    array[i + 1] = otherListeners.get(i);
                }
                listeners = array;
            }
        }
            }
}
