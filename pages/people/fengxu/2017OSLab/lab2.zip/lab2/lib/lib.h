#ifndef __lib_h__
#define __lib_h__

#define SYS_WRITE 0
#define STD_OUT 0

#define MAX_BUFFER_SIZE 256
//#define MAX_BUFFER_SIZE 1

void printf(const char *format,...);

#endif
