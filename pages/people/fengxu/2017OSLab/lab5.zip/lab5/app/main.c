#include "types.h"
#include "utils.h"
#include "lib.h"

/*
int data = 0;

int uEntry(void) {
	//uint16_t selector;
	////uint16_t selector = 16;
	//asm volatile("movw %%ss, %0":"=m"(selector)); //XXX necessary or not, iret may reset ds in QEMU
	//asm volatile("movw %%ax, %%ds"::"a"(selector));

	//asm volatile("cli"); //XXX test for CPL, will cause a #GP
	//asm volatile("int $0xe"); //XXX test for SWInterrupt/exception:fault, current instruction address is pushed into kernel stack, if idt[0xe].dpl>=cpl, o.w., cause #GP
	//asm volatile("int $0x80");//XXX test for SWInterrupt, next instruction address is pushed into kernel stack, if idt[0x80].dpl>=cpl, o.w., cause #GP
	//asm volatile("int 3 ...");//XXX equivalent to int 0x3?
	//asm volatile("into ...");//XXX equivalent to int 0x4?
	//asm volatile("bound ...");//XXX equivalent to int 0x5?
	//printf("1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n21\n22\n23\n24\n25\n26\n27\n");
	//printf("Scroll Screen Test.\n");
	
	//printf("printf test begin...\n");
	//printf("Task switching test begin...\n");
	
	int dec = 0;
	int hex = 0;
	char str[6];
	char cha = 0;
	int ret = 0;
	while(1){
		printf("Input:\" Test %%c Test %%6s %%d %%x\"\n");
		ret = scanf(" Test %c Test %6s %d %x", &cha, str, &dec, &hex);
		printf("Ret: %d; %c, %s, %d, %x.\n", ret, cha, str, dec, hex);
		if (ret == 4)
			break;
	}
	
	int i = 4;

	sem_t sem;
	printf("Father Process: Semaphore Initializing.\n");
	ret = sem_init(&sem, 2);
	if (ret == -1) {
		printf("Father Process: Semaphore Initializing Failed.\n");
		exit();
	}

	ret = fork();
	if (ret == 0) {
		while( i != 0) {
			i --;
			printf("Child Process: Semaphore Waiting.\n");
			sem_wait(&sem);
			printf("Child Process: In Critical Area.\n");
		}
		printf("Child Process: Semaphore Destroying.\n");
		sem_destroy(&sem);
		exit();
	}
	else if (ret != -1) {
		while( i != 0) {
			i --;
			printf("Father Process: Sleeping.\n");
			sleep(128);
			printf("Father Process: Semaphore Posting.\n");
			sem_post(&sem);
		}
		printf("Father Process: Semaphore Destroying.\n");
		sem_destroy(&sem);
		exit();
	}
	
	return 0;
}
*/

union DirEntry {
	uint8_t byte[128];
	struct {
		int32_t inode;
		char name[64];
	};
};

typedef union DirEntry DirEntry;

int ls(char *destFilePath) {
	printf("ls %s\n", destFilePath);
	int i = 0;
	int fd = 0;
	int ret = 0;
	DirEntry *dirEntry = 0;
	uint8_t buffer[512 * 2];
	fd = open(destFilePath, O_READ | O_DIRECTORY);
	if (fd == -1)
		return -1;
	ret = read(fd, buffer, 512 * 2);
	while (ret != 0) {
		dirEntry = (DirEntry *)buffer;
		for (i = 0; i < (512 * 2) / sizeof(DirEntry); i ++) {
			if (dirEntry[i].inode != 0)
				printf("%s ", dirEntry[i].name);
		}
		ret = read(fd, buffer, 512 * 2);
	}
	printf("\n");
	close(fd);
	return 0;
}

int cat(char *destFilePath) {
	printf("cat %s\n", destFilePath);
	int fd = 0;
	int ret = 0;
	uint8_t buffer[512 * 2];
	fd = open(destFilePath, O_READ);
	if (fd == -1)
		return -1;
	ret = read(fd, buffer, 512 * 2);
	while (ret != 0) {
		write(STD_OUT, buffer, ret);
		ret = read(fd, buffer, 512 * 2);
	}
	close(fd);
	return 0;
}

int uEntry(void) {
/* stdin test */
//	int dec = 0;
//	int hex = 0;
//	char str[6];
//	char cha = 0;
//	int ret = 0;
//	while(1){
//		printf("Input:\" Test %%c Test %%6s %%d %%x\"\n");
//		ret = scanf(" Test %c Test %6s %d %x", &cha, str, &dec, &hex);
//		printf("Ret: %d; %c, %s, %d, %x.\n", ret, cha, str, dec, hex);
//		if (ret == 4)
//			break;
//	}
/* filesystem test */
	int fd = 0;
	int i = 0;
	char tmp = 0;
	
	ls("/");
	ls("/boot/");
	ls("/dev/");
	ls("/usr/");

	printf("create /usr/test and write alphabets to it\n");
	fd = open("/usr/test", O_WRITE | O_READ | O_CREATE);
	//write(fd, (uint8_t*)"Hello, World!\n", 14);
	//write(fd, (uint8_t*)"This is a demo!\n", 16);
	//for (i = 0; i < 2049; i ++) {
	//for (i = 0; i < 2048; i ++) {
	//for (i = 0; i < 1025; i ++) {
	//for (i = 0; i < 512; i ++) {
	for (i = 0; i < 26; i ++) {
		tmp = (char)(i % 26 + 'A');
		write(fd, (uint8_t*)&tmp, 1);
	}
	close(fd);
	ls("/usr/");
	cat("/usr/test");
	printf("\n");
	printf("rm /usr/test\n");
	remove("/usr/test");
	ls("/usr/");
	printf("rmdir /usr/\n");
	remove("/usr/");
	//remove("/dev");
	ls("/");
	//ls("/dev");
	printf("create /usr/\n");
	fd = open("/usr/", O_CREATE | O_DIRECTORY);
	close(fd);
	ls("/");
	//fd = open("/usr/test", O_WRITE | O_READ);
	//close(fd);
	//ls("/usr");
	//fd = open("/usr/test/", O_CREATE);
	//close(fd);
	//ls("/usr/");
	//fd = open("/usr/test", O_CREATE);
	//close(fd);
	//ls("/usr/");
/* semaphore test */	
//	i = 4;
//
//	sem_t sem;
//	printf("Father Process: Semaphore Initializing.\n");
//	ret = sem_init(&sem, 2);
//	if (ret == -1) {
//		printf("Father Process: Semaphore Initializing Failed.\n");
//		exit();
//	}
//
//	ret = fork();
//	if (ret == 0) {
//		while( i != 0) {
//			i --;
//			printf("Child Process: Semaphore Waiting.\n");
//			sem_wait(&sem);
//			printf("Child Process: In Critical Area.\n");
//		}
//		printf("Child Process: Semaphore Destroying.\n");
//		sem_destroy(&sem);
//		exit();
//	}
//	else if (ret != -1) {
//		while( i != 0) {
//			i --;
//			printf("Father Process: Sleeping.\n");
//			sleep(128);
//			printf("Father Process: Semaphore Posting.\n");
//			sem_post(&sem);
//		}
//		printf("Father Process: Semaphore Destroying.\n");
//		sem_destroy(&sem);
//		exit();
//	}
	
	exit();
	return 0;
}
