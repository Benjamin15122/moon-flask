Usage: java -jar GraphSimilarity.jar autodroid bigraph -d1 <graphDir1> -d2 <graphDir2> -o <outputFilePath>  -s 0
-d1/d2 graphDir1/graphDir2: The "strategy_output" folders that need to be compared
-o outputFilePath: The output similarity result file path. Such as "output_result.txt"
-s 0: Don't change this parameter


Output Format
File ends with "_edge"
The output data is a table, the columns of which are split by space and their meanings are:
apk1 apk2 KM edgeCount1 edgeCount2
(The edgeCount2 is always no larger than edgeCount1 since we did the comparison. )

File ends with "_time"
The time consumption (second) for each comparision.