RepDroid consists of two parts: AutoDroid and GraphSimilarity

You should first run the AutoDroid to get "output_strategy", which contains the LGGs of each app.

Then run GraphSimilarity to calculate the similarity between LGGs.

Notice:
AutoDroid only tests in Windows 10 OS.