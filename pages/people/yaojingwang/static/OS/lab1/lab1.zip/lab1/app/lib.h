void print()
{
	while(1);
}