#include "lib.h"

void main()
{
	print();
}