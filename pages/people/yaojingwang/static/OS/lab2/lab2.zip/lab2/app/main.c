#include "lib.h"

void
uentry(void){
    while(1);
}