function [F,H]=LIWINE(network,para)
% The LIWINE algorithm

% dim, step-size, maxIter, sampling
%para = [128, 0.01, 100, 1]; 
dim = para(1);
step = para(2);
maxIte = para(3);
sampling = para(4);

% initialize F and H matrices
[m, n] = size(network);
if m == 3890
    F_name = 'PPI/F0128.txt';
    H_name = 'PPI/H0128.txt';
elseif m == 10312
    F_name = 'blogcata/F0128.txt';
    H_name = 'blogcata/H0128.txt';
elseif m == 80513
    F_name = 'flickr/F0128.txt';
    H_name = 'flickr/H0128.txt';
elseif m == 3312
    F_name = 'citeseer/F0128.txt';
    H_name = 'citeseer/H0128.txt';
elseif m == 2405
    F_name = 'wiki/F0128.txt';
    H_name = 'wiki/H0128.txt';
end
F0 = load(F_name);
H0 = load(H_name);

r = 1;
for iter = 1:maxIte
    F1 = F0;
    H1 = H0;
    if mod(iter,10) == 0
        fprintf('Ite = %d\n', iter);
    end
    
    if sampling == 1 % partial random sampling
        for i=1:m
            sample_ids = add_neg_sample(network(i,:),r);
            tmp1 = 1./(1+exp(-F0(i,:)*H0(sample_ids,:)'));
            tmp = 1-tmp1;
            tmp2 = tmp1.*tmp;
            tmpr = network(i,sample_ids);
            W = 1./sum(tmp1,2);
            Wr = 1./sum(tmpr,2);
            tempr = Wr.*tmpr;
            temp2 = W.*tmp2;
            gra_Fi=(temp2-tempr.*tmp)*H0(sample_ids,:);
            F0(i,:)=F0(i,:)-step*gra_Fi;
        end

        for j=1:n
            sample_ids = add_neg_sample(network(:,j),r);
            tmp1 = 1./(1+exp(-F0(sample_ids,:)*H0(j,:)'));
            tmp = 1-tmp1;
            tmp2 = tmp1.*tmp;
            tmpr = network(sample_ids,j);
            W = 1./sum(tmp1);
            Wr = 1./sum(tmpr);
            tempr = Wr.*tmpr;
            temp2 = W.*tmp2;
            gra_Hj=(tempr.*(temp2-tmp))'*F0(sample_ids,:);
            H0(j,:)=H0(j,:)-step*gra_Hj;
        end
    elseif sampling == 2 % full sampling
        tmp1 = 1./(1+exp(-F0*H0'));
        tmp = 1-tmp1;
        tmp2 = tmp1.*tmp;
        tmpr = network;
        W = sparse(1:m,1:m,1./sum(tmp1,2),m,m);
        Wr = sparse(1:m,1:m,1./sum(tmpr,2),m,m);
        tempr = Wr*tmpr;
        temp2 = W*tmp2;
        
        gra_F=(temp2-tempr.*tmp)*H0;
        F0=F0-step*gra_F;
        
        gra_H=(tempr.*(temp2-tmp))'*F0;
        H0=H0-step*gra_H;
    end
            
    if norm(F1-F0, 'fro') < 10^-6 && norm(H1-H0, 'fro') < 10^-6
        break
    end
end

F = F0;
H = H0;

end

% partial random sampling
function sample_ids = add_neg_sample(data,k)
[m,n] = size(data);
[i,j] = find(data);
[i0,j0] = find(data == 0);
if m == 1
    pos_num = size(j,2);
    neg_num = size(j0,2);
    pp = randperm(neg_num);
    sample_ids = [j, pp(:,1:pos_num*k)];
elseif n == 1
    pos_num = size(i,1);
    neg_num = size(i0,1);
    pp = randperm(neg_num);
    pp = pp';
    sample_ids = [i; pp(1:pos_num*k,:)];
end
end

