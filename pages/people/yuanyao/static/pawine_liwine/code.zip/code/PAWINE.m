function [F, H] = PAWINE(network, para)
% The pawine algorithm

%rank, lambda_d, lambda, step-size, maxIte
%para = [128, 0.01, 0.01, 0.01, 100000]; 
dim = para(1);
lambda_d = para(2);
lambda = para(3);
step = para(4);
maxIte = para(5);

% initialize F and H matrices
[m, n] = size(network);
if m == 3890
    F_name = 'PPI/F0128.txt';
    H_name = 'PPI/H0128.txt';
elseif m == 10312
    F_name = 'blogcata/F0128.txt';
    H_name = 'blogcata/H0128.txt';
elseif m == 80513
    F_name = 'flickr/F0128.txt';
    H_name = 'flickr/H0128.txt';
elseif m == 3312
    F_name = 'citeseer/F0128.txt';
    H_name = 'citeseer/H0128.txt';
elseif m == 2405
    F_name = 'wiki/F0128.txt';
    H_name = 'wiki/H0128.txt';
end
F0 = load(F_name);
H0 = load(H_name);

% add bias into the basic pairwise term (omitted from the paper for brevity)
[I,J] = find(network);
t_size = size(I,1);
avg = t_size/m/n;
B0 = sum(network,1)'/m - avg;

for iter = 1:maxIte
    F1 = F0;
    H1 = H0;
    if mod(iter,10000) == 0
        fprintf('Ite = %d\n', iter);
    end
    for iter_rand = 1:m
        % randomly sample (i,j,k)
        seed = ceil(rand()*t_size);
        i = I(seed, 1);
        j = J(seed, 1);
        while 1
            k = ceil(rand()*n);
            if network(i, k) == 0
                break
            end
        end
        
        r_ijk = F0(i,:) * (H0(j,:) - H0(k,:))' + (B0(j) - B0(k));
        r_ij = F0(i,:) * H0(j,:)';
        r_ik = -F0(i,:) * H0(k,:)';
        loss_ijk = -1 / (1+exp(r_ijk));
        loss_ij = -1 / (1+exp(r_ij));
        loss_ik = -1 / (1+exp(r_ik));
        
        % update F
        gra_Fi = network(i,j)*loss_ijk * (H0(j,:)-H0(k,:)) + lambda_d*network(i,j)*loss_ij*F0(j,:) - lambda_d*network(i,j)*loss_ik*F0(k,:) + lambda * F0(i,:);
        F0(i,:) = F0(i,:) - step * gra_Fi;
        gra_Fj = lambda_d*network(i,j)*loss_ij*F0(i,:) + lambda * F0(j,:);
        F0(j,:) = F0(j,:) - step * gra_Fj;
        gra_Fk = lambda_d*network(i,j)*(-loss_ik*F0(i,:)) + lambda * F0(k,:);
        F0(k,:) = F0(k,:) - step * gra_Fk;
        % update H
        gra_Hi = network(i,j)*loss_ijk * F0(i,:) + lambda * H0(j,:);
        H0(j,:) = H0(j,:) - step * gra_Hi;
        gra_Hj = network(i,j)*loss_ijk * (-F0(i,:)) + lambda * H0(k,:);
        H0(k,:) = H0(k,:) - step * gra_Hj;
        % update B
        gra_Bj = network(i,j)*loss_ijk + lambda * B0(j);
        B0(j) = B0(j) - step * gra_Bj;
        gra_Bk = -network(i,j)*loss_ijk + lambda * B0(k);
        B0(k) = B0(k) - step * gra_Bk;
    end
    
    if norm(F1-F0, 'fro') < 10^-6 && norm(H1-H0, 'fro') < 10^-6
        break
    end
end

F = F0;
H = H0;

end