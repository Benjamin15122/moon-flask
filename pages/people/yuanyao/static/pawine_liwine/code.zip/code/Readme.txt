In this package, we provide the code and data for the PAWINE and LIWINE algorithms.

1. We provide both the matlab implementation and the C/C++ implementation.

2. For the matlab code:
  - You may first load the data in the corresponding folder (e.g., PPI.mat in the PPI folder). We only include the PPI data here, and you may download the other datasets through Google or contact the first author at y.yao@nju.edu.cn.
  - Then, you can try "[F, H] = PAWINE(network, [128, 0.01, 0.01, 0.01, 100000])" for the PAWINE algorithm, or try either "[F,H]=LIWINE(network,[128, 1, 100, 2])" or "[F,H]=LIWINE(network,[128, 0.1, 50, 1])" for the LIWINE algorithm. The learned embedding is the F matrix. 
  - For the two commands of LIWINE, the former one uses full sampling, and the latter one uses partial random sampling.
  - Based on the obtained embeddings, you may try scoring functions in diffferent tasks (e.g., the scoring.py in https://github.com/phanein/deepwalk).

3. For the C/C++ code:
  - For Linux users, the compile and execution commands are in the train_PPI.sh.
  - We have included an executable for both algorithms, and you may try "./pawine -train PPI/PPI.txt -Fmatrix PPI/F0128.txt -Hmatrix PPI/H0128.txt -output vec_PPI_pawine.embeddings -size 128 -negative 1 -samples 2 -step 0.01 -threads 1
" for PAWINE, or "./liwine -train PPI/PPI.txt -Fmatrix PPI/F0128.txt -Hmatrix PPI/H0128.txt -output vec_PPI_liwine.embeddings -size 128 -negative 1 -iter 100 -step 0.01 -threads 1" for LIWINE. 
  - The explanations of the parameters are in the source code. For example, in LIWINE, -negative defines the number of negative sample ratio for each positive sample for partial random sampling strategy.


If there's any problem about the code, feel free to contact the first author.