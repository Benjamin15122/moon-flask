#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <pthread.h>
#include <gsl/gsl_rng.h>


#define MAX_STRING 100
#define SIGMOID_BOUND 6
#define NEG_SAMPLING_POWER 0
#define NEG_SAMPLING_POWER_BAK 0.75
#define EULERNUMBER 2.718281828

const int hash_table_size = 300000000;
const int neg_table_size = 1e8;
const int sigmoid_table_size = 1000;

typedef float real;                    // Precision of float numbers

struct ClassVertex {
    double degree;
    char *name;
};

struct ClassEdge {
	int source;
	int dest;
};

char Umatrix[MAX_STRING], Vmatrix[MAX_STRING], Bmatrix[MAX_STRING];
char network_file[MAX_STRING], embedding_file[MAX_STRING], embedding_file_V[MAX_STRING];
struct ClassVertex *vertex;
struct ClassEdge *edges;
int is_random = 0, num_threads = 1, dim = 128, num_negative = 1;
int *vertex_hash_table, *neg_table, *neg_size, *has_table, *hash_table2;
long long max_vertices;
long long edge_index;
int max_num_vertices = 1000, num_vertices = 0, max_num_edges = 10000;
long long max_iter = 100, current_sample_count = 0, num_edges = 0;
real step = 0.01;
real *F0, *H0;
real *sigmoid_table;

real neg_pow = NEG_SAMPLING_POWER;

int *edge_source_id, *edge_target_id;
double *edge_weight;

real sample_r = 1;

// Parameters for edge sampling
long long *alias;
double *prob;

const gsl_rng_type * gsl_T;
gsl_rng * gsl_r;

/* Build two hash table, table one maps each vertex name to a unique vertex id 
table two maps each edge with vertex id */
unsigned int Hash(char *key)
{
    unsigned int seed = 131;
    unsigned int hash = 0;
    while (*key)
    {
        hash = hash * seed + (*key++);
    }
    return hash % hash_table_size;
}

void InitHashTable()
{
    vertex_hash_table = (int *)malloc(hash_table_size * sizeof(int));
    for (int k = 0; k != hash_table_size; k++) vertex_hash_table[k] = -1;
}

void InsertHashTable(char *key, int value)
{
    int addr = Hash(key);
    while (vertex_hash_table[addr] != -1) addr = (addr + 1) % hash_table_size;
    vertex_hash_table[addr] = value;
}

int SearchHashTable(char *key)
{
    int addr = Hash(key);
    while (1)
    {
        if (vertex_hash_table[addr] == -1) return -1;
        if (!strcmp(key, vertex[vertex_hash_table[addr]].name)) return vertex_hash_table[addr];
        addr = (addr + 1) % hash_table_size;
    }
    return -1;
}

void InsertHashTable2(char *key, int value)
{
    int addr = Hash(key);
    while (hash_table2[addr] != -1) addr = (addr + 1) % hash_table_size;
    hash_table2[addr] = value;
}

int SearchHashTable2(int source, int dest)
{
	char key4hash[50];
	sprintf(key4hash,"%lld", source*max_vertices+dest);
    int addr = Hash(key4hash);
    while (1)
    {
        if (hash_table2[addr] == -1) return -1;
        if (source == edges[hash_table2[addr]].source && dest == edges[hash_table2[addr]].dest) return hash_table2[addr];
        addr = (addr + 1) % hash_table_size;
    }
    return -1;
}

/* Add a vertex to the vertex set */
int AddEdge(int source, int dest)
{
	edges[edge_index].source = source;
	edges[edge_index].dest = dest;
	edge_index++;
	if (edge_index + 2 > max_num_edges)
	{
		max_num_edges += 10000;
		edges = (struct ClassEdge*)realloc(edges, max_num_edges * sizeof(struct ClassEdge));
	}
    char key4hash[50];
	sprintf(key4hash,"%lld", source*max_vertices+dest);
	InsertHashTable2(key4hash, edge_index - 1);
	return edge_index -1;
}

/* Add a vertex to the vertex set */
int AddVertex(char *name)
{
    int length = strlen(name) + 1;
    if (length > MAX_STRING) length = MAX_STRING;
    vertex[num_vertices].name = (char *)calloc(length, sizeof(char));
    strncpy(vertex[num_vertices].name, name, length-1);
    vertex[num_vertices].degree = 0;
    num_vertices++;
    if (num_vertices + 2 >= max_num_vertices)
    {
        max_num_vertices += 1000;
        vertex = (struct ClassVertex *)realloc(vertex, max_num_vertices * sizeof(struct ClassVertex));
    }
    InsertHashTable(name, num_vertices - 1);
    return num_vertices - 1;
}

/* Read network from the training file */
void ReadData()
{
    FILE *fin;
    char name_v1[MAX_STRING], name_v2[MAX_STRING], str[2 * MAX_STRING + 10000];
    int vid;
    double weight;

    fin = fopen(network_file, "rb");
    if (fin == NULL)
    {
        printf("ERROR: network file not found!\n");
        exit(1);
    }
    num_edges = 0;
    while (fgets(str, sizeof(str), fin)) num_edges++;
    fclose(fin);
    printf("Number of edges: %lld          \n", num_edges);

    edge_source_id = (int *)malloc(num_edges*sizeof(int));
    edge_target_id = (int *)malloc(num_edges*sizeof(int));
    edge_weight = (double *)malloc(num_edges*sizeof(double));
    if (edge_source_id == NULL || edge_target_id == NULL || edge_weight == NULL)
    {
        printf("Error: memory allocation failed!\n");
        exit(1);
    }

    float max_degree = 0;
    fin = fopen(network_file, "r");
    num_vertices = 0;
    for (int k = 0; k != num_edges; k++)
    {
        fscanf(fin, "%s %s %lf", name_v1, name_v2, &weight);

        if (k % 10000 == 0)
        {
            printf("Reading edges: %.3lf%%%c", k / (double)(num_edges + 1) * 100, 13);
            fflush(stdout);
        }

        vid = SearchHashTable(name_v1);
        if (vid == -1) vid = AddVertex(name_v1);
        vertex[vid].degree += weight;
        edge_source_id[k] = vid;
        if(vertex[vid].degree > max_degree) max_degree = vertex[vid].degree;

        vid = SearchHashTable(name_v2);
        if (vid == -1) vid = AddVertex(name_v2);
        vertex[vid].degree += weight;
        edge_target_id[k] = vid;

        edge_weight[k] = weight;
    }
    fclose(fin);
    printf("Number of vertices: %d          \n", num_vertices);
    max_degree ++;
    hash_table2 = (int*)malloc(hash_table_size * sizeof(int));
    for (int k = 0; k != hash_table_size; k++) hash_table2[k] = -1;
    max_vertices = 1;
    while(max_vertices < num_vertices) max_vertices *= 10;

    fin = fopen(network_file, "r");
    for (int k = 0; k != num_edges; k++)
    {
        fscanf(fin, "%s %s %lf", name_v1, name_v2, &weight);

        if (k % 10000 == 0)
        {
            printf("Again Reading edges: %.3lf%%%c", k / (double)(num_edges + 1) * 100, 13);
            fflush(stdout);
        }

        int vid1 = SearchHashTable(name_v1);
        int vid2 = SearchHashTable(name_v2);
        AddEdge(vid1, vid2);

    }
    fclose(fin);
    printf("Loading Hashtable Finished             \n");
}

void ReadMatrix()
{
    FILE *fin;
    double value;
    char key4hash[50];
    fin = fopen(Umatrix, "r");
    for(int ver = 0; ver != num_vertices; ver ++)
    {   
        sprintf(key4hash, "%d", ver);
        int lver = SearchHashTable(key4hash);
        lver = lver * dim;
        for(int c = 0; c != dim; c++)
        {
            fscanf(fin, "%lf", &value);
            F0[lver + c] = value;
        }
    }
    fclose(fin);
    printf("Umatrix Read over\n");
    fflush(stdout);

    fin = fopen(Vmatrix, "r");
    for(int ver = 0; ver != num_vertices; ver ++)
    {   
        sprintf(key4hash, "%d", ver);
        int lver = SearchHashTable(key4hash);
        lver = lver * dim;
        for(int c = 0; c != dim; c++)
        {
            fscanf(fin, "%lf", &value);
            H0[lver + c] = value;
        }
    }
    fclose(fin);
    printf("Vmatrix Read over\n");
    fflush(stdout);

}

/* The alias sampling algorithm, which is used to sample an edge in O(1) time. */
void InitAliasTable()
{
    alias = (long long *)malloc(num_edges*sizeof(long long));
    prob = (double *)malloc(num_edges*sizeof(double));
    if (alias == NULL || prob == NULL)
    {
        printf("Error: memory allocation failed!\n");
        exit(1);
    }

    double *norm_prob = (double*)malloc(num_edges*sizeof(double));
    long long *large_block = (long long*)malloc(num_edges*sizeof(long long));
    long long *small_block = (long long*)malloc(num_edges*sizeof(long long));
    if (norm_prob == NULL || large_block == NULL || small_block == NULL)
    {
        printf("Error: memory allocation failed!\n");
        exit(1);
    }

    double sum = 0;
    long long cur_small_block, cur_large_block;
    long long num_small_block = 0, num_large_block = 0;

    for (long long k = 0; k != num_edges; k++) sum += edge_weight[k];
    for (long long k = 0; k != num_edges; k++) norm_prob[k] = edge_weight[k] * num_edges / sum;

    for (long long k = num_edges - 1; k >= 0; k--)
    {
        if (norm_prob[k]<1)
            small_block[num_small_block++] = k;
        else
            large_block[num_large_block++] = k;
    }

    while (num_small_block && num_large_block)
    {
        cur_small_block = small_block[--num_small_block];
        cur_large_block = large_block[--num_large_block];
        prob[cur_small_block] = norm_prob[cur_small_block];
        alias[cur_small_block] = cur_large_block;
        norm_prob[cur_large_block] = norm_prob[cur_large_block] + norm_prob[cur_small_block] - 1;
        if (norm_prob[cur_large_block] < 1)
            small_block[num_small_block++] = cur_large_block;
        else
            large_block[num_large_block++] = cur_large_block;
    }

    while (num_large_block) prob[large_block[--num_large_block]] = 1;
    while (num_small_block) prob[small_block[--num_small_block]] = 1;

    free(norm_prob);
    free(small_block);
    free(large_block);
}

long long SampleAnEdge(double rand_value1, double rand_value2)
{
    long long k = (long long)num_edges * rand_value1;
    return rand_value2 < prob[k] ? k : alias[k];
}

/* Initialize the vertex embedding and the context embedding */
void InitVector()
{
    long long a, b;

    a = posix_memalign((void **)&F0, 128, (long long)num_vertices * dim * sizeof(real));
    if (F0 == NULL) { printf("Error: memory allocation failed\n"); exit(1); }
    for (b = 0; b < dim; b++) for (a = 0; a < num_vertices; a++)
        F0[a * dim + b] = (rand() / (real)RAND_MAX - 0.5) / dim;

    a = posix_memalign((void **)&H0, 128, (long long)num_vertices * dim * sizeof(real));
    if (H0 == NULL) { printf("Error: memory allocation failed\n"); exit(1); }
    for (b = 0; b < dim; b++) for (a = 0; a < num_vertices; a++)
        H0[a * dim + b] = (rand() / (real)RAND_MAX - 0.5) / dim;
}

/* Sample negative vertex samples according to vertex degrees */
void InitNegTable()
{
    double sum = 0, cur_sum = 0, por = 0;
    int vid = 0;
    neg_table = (int *)malloc(neg_table_size * sizeof(int));
    for (int k = 0; k != num_vertices; k++) sum += pow(vertex[k].degree, neg_pow);
    for (int k = 0; k != neg_table_size; k++)
    {
        if ((double)(k + 1) / neg_table_size > por)
        {
            cur_sum += pow(vertex[vid].degree, neg_pow);
            por = cur_sum / sum;
            vid++;
        }
        neg_table[k] = vid - 1;
    }
}

/* Fastly compute sigmoid function */
void InitSigmoidTable()
{
    real x;
    sigmoid_table = (real *)malloc((sigmoid_table_size + 1) * sizeof(real));
    for (int k = 0; k != sigmoid_table_size; k++)
    {
        x = 2 * SIGMOID_BOUND * k / sigmoid_table_size - SIGMOID_BOUND;
        sigmoid_table[k] = 1 / (1 + exp(-x));
    }
}

real FastSigmoid(real x)
{
    if (x > SIGMOID_BOUND) return 1;
    else if (x < -SIGMOID_BOUND) return 0;
    int k = (x + SIGMOID_BOUND) * sigmoid_table_size / SIGMOID_BOUND / 2;
    return sigmoid_table[k];
}

/* Fastly generate a random integer */
int Rand(unsigned long long &seed)
{
    seed = seed * 25214903917 + 11;
    return (seed >> 16) % neg_table_size;
}

void *TrainLINEThread(void *id)
{
    long long lu, li;
    char key4Hash[50];
    long long j, lj;
    long long count = 0, last_count = 0;
    unsigned long long seed = (long long)id;
    real gra;
    int *sample_ids = (int*)malloc(num_vertices * num_vertices * sizeof(int));
    int *sample_ids_size = (int*)malloc(num_vertices * sizeof(int));
    for(int ver_id = 0; ver_id != num_vertices; ver_id++)
    {
       lu = ver_id * num_vertices;
       sample_ids_size[ver_id] = 0;
       for(int ver_id_n = 0; ver_id_n != num_vertices;ver_id_n++)
       {
           sprintf(key4Hash,"%lld",ver_id*max_vertices+ver_id_n);
           if(SearchHashTable2(ver_id, ver_id_n) != -1)
           {
               sample_ids[lu + sample_ids_size[ver_id]] = ver_id_n;
               sample_ids_size[ver_id] += 1;
           }
       }
    }

	while (1)
    {
        //judge for exit
        if (count > max_iter / num_threads + 2) break;

        if (count - last_count>10)
        {
            current_sample_count += count - last_count;
            last_count = count;
            printf("%cProgress: %.3lf%%", 13, (real)current_sample_count / (real)(max_iter + 1) * 100);
            fflush(stdout);
        }

        for(int ver_id = 0; ver_id != num_vertices; ver_id++)
        {
            li = ver_id * dim;
            lu = ver_id * num_vertices;
            //sampleing pos + neg
            for(int r = 0; r != sample_ids_size[ver_id] * sample_r; r++)
            {
                while(1)
				{
					j = neg_table[Rand(seed)];
					if(SearchHashTable2(ver_id, j) == -1) break ;
				}
                sample_ids[lu + sample_ids_size[ver_id] + r] = j;
            }
            
            
            real *tmp1 = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++)
            {
                lj = sample_ids[lu+i] * dim;
                tmp1[i] = 0.0;
                for(int c = 0; c != dim; c++)
                {
                    tmp1[i] += F0[li + c] * H0[lj + c];
                }
				tmp1[i] = FastSigmoid(tmp1[i]);
            }

          
            real *tmp = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tmp[i] = 1-tmp1[i];

            
            real *tmp2 = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tmp2[i] = tmp1[i]*tmp[i];

            
            real *tmpr = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id];i++) tmpr[i] = 1;
            for(int i = sample_ids_size[ver_id]; i != sample_ids_size[ver_id]*(sample_r+1);i++)
            {
                if(SearchHashTable2(ver_id, sample_ids[lu+i]) != -1) tmpr[i] = 1;
                else tmpr[i] = 0;
            }

            
            gra = 0;
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) gra += tmp1[i];
            real W = 1/gra;
            free(tmp1);

            
            gra = 0;
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) gra += tmpr[i];
            real Wr = 1/gra;

            
            real *tempr = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tempr[i] = Wr * tmpr[i];
            free(tmpr);
            
            real *temp2 = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) temp2[i] = W * tmp2[i];
            free(tmp2);

			for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tmp[i] = temp2[i] - tempr[i] * tmp[i];
		    real *gra_Fi = (real*)malloc(dim * sizeof(real));
            for(int c = 0; c != dim;c++) gra_Fi[c] = 0;
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) 
            {
			    lj = sample_ids[lu+i] * dim;
                for(int c = 0; c!= dim; c++)
		            gra_Fi[c] += tmp[i] * H0[lj+c];
            }
            free(tempr);free(temp2);free(tmp);

            for(int c = 0; c != dim; c++)
		        F0[li + c] = F0[li + c] - step * gra_Fi[c];
		    free(gra_Fi);
        }

        for(int ver_id = 0; ver_id != num_vertices; ver_id++)
        {
            li = ver_id * dim;
            lu = ver_id * num_vertices;
            //sampleing pos + neg
            for(int r = 0; r != sample_ids_size[ver_id] * sample_r; r++)
            {
			    while(1)
				{
                    j = neg_table[Rand(seed)];
                    if(SearchHashTable2(ver_id, j) == -1) break;
				}
                sample_ids[lu + sample_ids_size[ver_id] + r] = j;
            }
            
            real *tmp1 = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++)
            {
                lj = sample_ids[lu+i] * dim;
                tmp1[i] = 0.0;
                for(int c = 0; c != dim; c++)
                {
                    tmp1[i] += H0[li + c] * F0[lj + c];
                }
				tmp1[i] = FastSigmoid(tmp1[i]);
            }

            real *tmp = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tmp[i] = 1-tmp1[i];

            real *tmp2 = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tmp2[i] = tmp1[i]*tmp[i];

            real *tmpr = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id];i++) tmpr[i] = 1;
            for(int i = sample_ids_size[ver_id]; i != sample_ids_size[ver_id]*(sample_r+1);i++)
            {
                if(SearchHashTable2(ver_id, sample_ids[lu+i]) != -1) tmpr[i] = 1;
                else tmpr[i] = 0;
            }

            gra = 0;
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) gra += tmp1[i];
            real W = 1/gra;
            free(tmp1);

            gra = 0;
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) gra += tmpr[i];
            real Wr = 1/gra;

            real *tempr = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tempr[i] = Wr * tmpr[i];
            free(tmpr);

            real *temp2 = (real*)malloc(sample_ids_size[ver_id] * (sample_r+1) * sizeof(real));
            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) temp2[i] = W * tmp2[i];
            free(tmp2);

            for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) tmp[i] = tempr[i] * (temp2[i] - tmp[i]);
			real *gra_Hj = (real*)malloc(dim * sizeof(real));
		    for(int c = 0; c != dim;c++) gra_Hj[c] = 0;
		    for(int i = 0; i != sample_ids_size[ver_id]*(sample_r+1);i++) 
			{
				lj = sample_ids[lu+i] * dim;
				for(int c = 0; c!= dim; c++)
				    gra_Hj[c] += tmp[i] * F0[lj+c];
			}
			free(tempr);free(temp2);free(tmp);

			for(int c = 0; c != dim; c++)
		        H0[li + c] = H0[li + c] - step * gra_Hj[c];
		    free(gra_Hj);
		}

        count++;
    }
    free(sample_ids);
    free(sample_ids_size);
    pthread_exit(NULL);
}

void Output()
{
    FILE *fo = fopen(embedding_file, "w");
    fprintf(fo, "%d %d\n", num_vertices, dim);
    for (int a = 0; a < num_vertices; a++)
    {
        fprintf(fo, "%s ", vertex[a].name);
        fflush(stdout);
        for (int b = 0; b < dim; b++) fprintf(fo, "%lf ", F0[a * dim + b]);
        fprintf(fo, "\n");
        fflush(stdout);
    }
    fclose(fo);
}

void TrainLINE() {
    long a;
    pthread_t *pt = (pthread_t *)malloc(num_threads * sizeof(pthread_t));
    
    if (is_random == 1)
    {
        neg_pow = NEG_SAMPLING_POWER_BAK;
    }
    printf("--------------------------------\n");
    printf("Samples: %lld\n", max_iter);
    printf("Negative: %d\n", num_negative);
    printf("Dimension: %d\n", dim);
    printf("Step: %f\n", step);
    printf("Negchoice: %d\n", is_random);
    printf("--------------------------------\n");

    InitHashTable();
    ReadData();
    InitAliasTable();
    InitVector();
    ReadMatrix();
    InitNegTable();
    InitSigmoidTable();

    gsl_rng_env_setup();
    gsl_T = gsl_rng_rand48;
    gsl_r = gsl_rng_alloc(gsl_T);
    gsl_rng_set(gsl_r, 314159265);

    clock_t start = clock();
    printf("--------------------------------\n");
    for (a = 0; a < num_threads; a++) pthread_create(&pt[a], NULL, TrainLINEThread, (void *)a);
    for (a = 0; a < num_threads; a++) pthread_join(pt[a], NULL);
    printf("\n");
    clock_t finish = clock();
    printf("Total time: %lf\n", (double)(finish - start) / CLOCKS_PER_SEC);

    Output();
}

int ArgPos(char *str, int argc, char **argv) {
    int a;
    for (a = 1; a < argc; a++) if (!strcmp(str, argv[a])) {
        if (a == argc - 1) {
            printf("Argument missing for %s\n", str);
            exit(1);
        }
        return a;
    }
    return -1;
}

int main(int argc, char **argv) {
    int i;
    if (argc == 1) {
        printf("LIWINE: LIst-Wise Information Network Embedding\n\n");
        printf("Options:\n");
        printf("Parameters for training:\n");
        printf("\t-train <file>\n");
        printf("\t\tUse network data from <file> to train the model\n");
        printf("\t-output <file>\n");
        printf("\t\tUse <file> to save the learnt embeddings\n");
        printf("\t-Fmatrix <file>\n");
        printf("\t\tUse <file> to init the F0\n");
        printf("\t-Hmatrix <file>\n");
        printf("\t\tUse <file> to init the H0\n");
        printf("\t-negchoice <int>\n");
        printf("\t\tselect the negative mode; default is 0 (random selection); 1 (degree based)\n");
        printf("\t-size <int>\n");
        printf("\t\tSet dimension of vertex embeddings; default is 128\n");
        printf("\t-negative <int>\n");
        printf("\t\tNumber of negative examples, <int> times of degree of each vertex; default is 1\n");
        printf("\t-iter <int>\n");
        printf("\t\tSet the number of training iterations <int> ; default is 100\n");
        printf("\t-threads <int>\n");
        printf("\t\tUse <int> threads (default 1)\n");
        printf("\t-step <float>\n");
        printf("\t\tSet the starting learning rate; default is 0.01\n");
        printf("\nExamples:\n");
        printf("./liwine -train net.txt -output vec.embeddings -Fmatrix F.txt -Hmatrix H.txt -negchoice 1 -size 128 -negative 1 -iter 1 -step 0.01 -threads 1\n\n");
        return 0;
    }
    if ((i = ArgPos((char *)"-Fmatrix", argc, argv)) > 0) strcpy(Umatrix, argv[i + 1]);
    if ((i = ArgPos((char *)"-Hmatrix", argc, argv)) > 0) strcpy(Vmatrix, argv[i + 1]);
    if ((i = ArgPos((char *)"-train", argc, argv)) > 0) strcpy(network_file, argv[i + 1]);
    if ((i = ArgPos((char *)"-output", argc, argv)) > 0) strcpy(embedding_file, argv[i + 1]);
    if ((i = ArgPos((char *)"-negchoice", argc, argv)) > 0) is_random = atoi(argv[i + 1]);
    if ((i = ArgPos((char *)"-size", argc, argv)) > 0) dim = atoi(argv[i + 1]);
    if ((i = ArgPos((char *)"-negative", argc, argv)) > 0) sample_r = atoi(argv[i + 1]);
    if ((i = ArgPos((char *)"-iter", argc, argv)) > 0) max_iter = atoi(argv[i + 1]);
    if ((i = ArgPos((char *)"-step", argc, argv)) > 0) step = atof(argv[i + 1]);
    if ((i = ArgPos((char *)"-threads", argc, argv)) > 0) num_threads = atoi(argv[i + 1]);

    vertex = (struct ClassVertex *)calloc(max_num_vertices, sizeof(struct ClassVertex));
    edges = (struct ClassEdge *)calloc(max_num_edges, sizeof(struct ClassEdge));
	TrainLINE();
    return 0;
}
