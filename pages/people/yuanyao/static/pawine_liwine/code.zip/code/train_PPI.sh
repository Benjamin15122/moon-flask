#!/bin/sh

g++ -lm -pthread -Ofast -march=native -Wall -funroll-loops -ffast-math -Wno-unused-result pawine.cpp -o pawine -lgsl -lm -lgslcblas
g++ -lm -pthread -Ofast -march=native -Wall -funroll-loops -ffast-math -Wno-unused-result liwine.cpp -o liwine -lgsl -lm -lgslcblas

./pawine -train PPI/PPI.txt -Fmatrix PPI/F0128.txt -Hmatrix PPI/H0128.txt -output vec_PPI_pawine.embeddings -size 128 -negative 1 -samples 2 -step 0.01 -threads 1
./liwine -train PPI/PPI.txt -Fmatrix PPI/F0128.txt -Hmatrix PPI/H0128.txt -output vec_PPI_liwine.embeddings -size 128 -negative 1 -iter 100 -step 0.01 -threads 1